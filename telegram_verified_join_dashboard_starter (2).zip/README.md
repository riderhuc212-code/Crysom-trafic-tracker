# Telegram Verified Join Dashboard (Netlify starter)

A responsive dashboard inspired by the supplied screenshots. It includes a dark/purple UI, Overview, Analytics, Campaigns, and Setup status pages, plus Netlify Function scaffolds and a PostgreSQL schema.

## Critical billing note
Meta Ads billing cannot be changed so that Meta charges only for verified Telegram joins. Meta bills according to its ad-delivery/billing model. This system is intended to measure verified joins and cost per verified join and, where policy and setup allow, send accurate conversion signals for optimization.

## What's included
- `public/`: responsive dashboard UI and client rendering.
- `netlify/functions/telegram-webhook.mjs`: webhook secret validation scaffold.
- `netlify/functions/track-click.mjs`: manual click endpoint scaffold.
- `netlify/functions/dashboard-api.mjs`: API response scaffold (returns zeros until a database adapter is implemented).
- `netlify/functions/meta-event.mjs`: deliberately disabled CAPI scaffold.
- `database/schema.sql`: PostgreSQL tables for sessions, clicks, Telegram updates, memberships, and Meta events.
- `.env.example`: environment-variable names only.

## Deploy to Netlify
1. Put this folder in a Git repository and import it into Netlify, or deploy with the Netlify CLI.
2. Build settings: publish directory `public`; functions directory `netlify/functions`.
3. Create a PostgreSQL database (e.g. Supabase or Neon) and apply `database/schema.sql`.
4. Configure `DATABASE_URL`, `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID`, `TELEGRAM_WEBHOOK_SECRET`, `META_PIXEL_ID`, `META_ACCESS_TOKEN` and optional `META_TEST_EVENT_CODE` as Netlify environment variables.
5. Deploy and test the dashboard route and `/api/dashboard-api`.

## Before production
This is a starter project, not a production-ready tracker yet. The DB adapter, secure admin authentication, rate limiting, Telegram update persistence/state machine, attribution matching, and Meta CAPI sender are intentionally marked as TODO/disabled. Do not count a button click or a join request as a verified member. A Telegram bot cannot reliably identify which anonymous landing-page visitor later joined unless you implement a privacy-conscious attribution mechanism (e.g. per-session invite links where supported and operationally appropriate). Never assume a join is attributable just because it occurred close in time to a click.

## Telegram webhook
After deployment, set Telegram's webhook to:
`https://YOUR-SITE.netlify.app/api/telegram-webhook`
Use Telegram's `secret_token` feature matching `TELEGRAM_WEBHOOK_SECRET`. Configure the bot to receive the required membership updates and test in a private test channel first. Avoid putting the bot token in a URL or client-side code.

## Meta CAPI
Use Meta's official Conversions API documentation and Test Events before production. Send events only after backend verification, keep `event_id` unique and stable, and use the same ID on browser/server copies only when intentionally deduplicating the same event. Do not send fabricated joins or personally identifying Telegram data without a lawful basis and appropriate notice/consent.

## Next required development
1. Add a PostgreSQL driver/connection and parameterized queries to every function.
2. Authenticate dashboard reads with an admin login/API session.
3. Process `update_id` idempotently and upsert member status from Telegram updates.
4. Implement attribution using a supported, testable Telegram flow; otherwise label joins as unattributed.
5. Implement CAPI sending from verified DB state, retry handling, event logs, and event deduplication.
6. Add campaign spend imports/manual spend input if you need cost per verified join. Meta spend is not automatically available just from Pixel events.
