// Never trust a browser-supplied event as proof of a Telegram join.
// This endpoint must only be called internally after DB state changes to verified.
// TODO: implement Meta Conversions API with server-held token, event_id shared with Pixel if browser event is also sent,
// event_source_url, action_source=website, and only permitted/necessary user data.
export default async (request) => {
  if(request.method!=="POST") return new Response("Method not allowed",{status:405});
  return Response.json({ok:false,configured:Boolean(process.env.META_PIXEL_ID&&process.env.META_ACCESS_TOKEN),
    message:"Not implemented: production CAPI sending is intentionally disabled until verified DB event processing is added."},{status:501});
};
