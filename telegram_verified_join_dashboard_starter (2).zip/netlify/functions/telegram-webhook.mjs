// Telegram webhook scaffold. Set Telegram webhook secret_token to TELEGRAM_WEBHOOK_SECRET.
// Verify Telegram's X-Telegram-Bot-Api-Secret-Token header before accepting updates.
export default async (request) => {
  if(request.method!=="POST") return new Response("Method not allowed",{status:405});
  const expected=process.env.TELEGRAM_WEBHOOK_SECRET;
  const supplied=request.headers.get("x-telegram-bot-api-secret-token");
  if(!expected || supplied!==expected) return new Response("Unauthorized",{status:401});
  let update; try{update=await request.json()}catch{return new Response("Invalid JSON",{status:400})}
  // TODO: persist update_id idempotently; handle chat_join_request and chat_member updates.
  // Only emit a verified-join event after server-side membership confirmation.
  return Response.json({ok:true,accepted:true,processed:false,updateId:update.update_id??null,
    message:"Webhook scaffold received update. Configure DB persistence and membership state machine before production."});
};
