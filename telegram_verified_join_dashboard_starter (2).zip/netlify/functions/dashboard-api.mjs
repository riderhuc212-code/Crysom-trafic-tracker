// Read-only dashboard API. Replace demo-safe empty values with SQL queries after DATABASE_URL is configured.
export default async () => {
  const configured = Boolean(process.env.DATABASE_URL);
  const metaConfigured = Boolean(process.env.META_PIXEL_ID && process.env.META_ACCESS_TOKEN);
  const telegramConfigured = Boolean(process.env.TELEGRAM_BOT_TOKEN && process.env.TELEGRAM_CHAT_ID && process.env.TELEGRAM_WEBHOOK_SECRET);
  return new Response(JSON.stringify({
    today:{visitors:0,clicks:0,joinRequests:0,verifiedJoins:0,metaEventsSent:0},
    daily:[],campaigns:[],
    health:{telegramWebhook:telegramConfigured?"Configured (verify webhook delivery)":"Not configured",database:configured?"Connection string present; DB query adapter required":"Not configured",metaCapi:metaConfigured?"Credentials present; send test event before production":"Not configured"},
    checks:[
      configured?"DATABASE_URL is set. Verify schema and connectivity.":"DATABASE_URL missing.",
      telegramConfigured?"Telegram environment variables are present. Register and verify webhook.":"Telegram bot, chat ID or webhook secret missing.",
      metaConfigured?"Meta credentials are present. Test Events and event deduplication still required.":"Meta Pixel ID or access token missing.",
      "This starter intentionally returns zero metrics until a real database adapter is configured."
    ]
  }),{status:200,headers:{"content-type":"application/json; charset=utf-8","cache-control":"no-store"}});
};
