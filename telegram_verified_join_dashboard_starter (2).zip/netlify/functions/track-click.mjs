// Server endpoint for manually-recorded Join clicks.
// Add a database insert + rate limiting before production. Do not treat clicks as verified joins.
export default async (request) => {
  if(request.method!=="POST") return new Response("Method not allowed",{status:405});
  let body; try{body=await request.json()}catch{return Response.json({error:"Invalid JSON"},{status:400})}
  const campaign=String(body.campaign||"").slice(0,200);
  const sessionId=String(body.sessionId||"").slice(0,100);
  if(!sessionId) return Response.json({error:"sessionId required"},{status:400});
  // TODO: persist an idempotent click record to the configured database.
  return Response.json({ok:true,recorded:false,message:"Endpoint scaffold only; connect database before production.",campaign});
};
