-- PostgreSQL schema starter (Supabase/Neon compatible).
-- Apply through your database console/migration tool. Never expose service-role credentials to browser code.
CREATE TABLE IF NOT EXISTS visitors (
  session_id TEXT PRIMARY KEY,
  first_seen_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  landing_path TEXT,
  utm_source TEXT,
  utm_medium TEXT,
  utm_campaign TEXT,
  utm_content TEXT,
  utm_term TEXT,
  fbclid TEXT,
  country_code TEXT,
  device_type TEXT
);
CREATE TABLE IF NOT EXISTS join_clicks (
  click_id TEXT PRIMARY KEY,
  session_id TEXT NOT NULL REFERENCES visitors(session_id),
  clicked_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  destination TEXT,
  UNIQUE(session_id, click_id)
);
CREATE TABLE IF NOT EXISTS telegram_updates (
  update_id BIGINT PRIMARY KEY,
  received_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  update_type TEXT NOT NULL,
  telegram_user_id BIGINT,
  chat_id BIGINT,
  payload JSONB NOT NULL DEFAULT '{}'::jsonb
);
CREATE TABLE IF NOT EXISTS memberships (
  chat_id BIGINT NOT NULL,
  telegram_user_id BIGINT NOT NULL,
  first_verified_at TIMESTAMPTZ,
  current_status TEXT NOT NULL DEFAULT 'unknown',
  last_status_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  source_session_id TEXT REFERENCES visitors(session_id),
  PRIMARY KEY(chat_id, telegram_user_id)
);
CREATE TABLE IF NOT EXISTS meta_events (
  event_id TEXT PRIMARY KEY,
  event_name TEXT NOT NULL,
  telegram_user_id BIGINT,
  session_id TEXT REFERENCES visitors(session_id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  sent_at TIMESTAMPTZ,
  response_code INTEGER,
  response_body JSONB
);
CREATE INDEX IF NOT EXISTS idx_visitors_first_seen ON visitors(first_seen_at);
CREATE INDEX IF NOT EXISTS idx_clicks_clicked_at ON join_clicks(clicked_at);
CREATE INDEX IF NOT EXISTS idx_memberships_verified ON memberships(first_verified_at);
CREATE INDEX IF NOT EXISTS idx_meta_events_created ON meta_events(created_at);
